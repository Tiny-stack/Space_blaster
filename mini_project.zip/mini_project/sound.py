from pygame.mixer import Sound
import pygame
pygame.init()
music=pygame.mixer.music.load("Matt.ogg")

print("played Sound")
pygame.mixer.music.play(-1)
while True:
    pass
    
