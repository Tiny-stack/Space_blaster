class myclass(object):
    x=1
    y=2
    z=3
    def __init__(self,x,y,z):
        self.x=x
        self.y=y
        self.z=z
    def area(self):
        return self.x*self.y*self.z
box=myclass(1,2,3)
print(box.area())
class subclass(myclass):
    def __init__(self):
        self.weight=5
    def mass(self):
        return self.x*self.y*self.z*self.weight
my=subclass()
print(my.area())
print(my.mass())
        
