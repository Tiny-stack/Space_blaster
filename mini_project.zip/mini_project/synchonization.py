import pygame     #WE work in the dark ,so that light may exist
from random import randint
import time
pygame.init()
win=pygame.display.set_mode((700,680))
pygame.display.set_caption("SPACE BLASTER")
clock=pygame.time.Clock()
bg=pygame.image.load('4bg.png') #Background image for good appearance
font=pygame.font.SysFont('Algerian',30)   # default font 
Load=pygame.image.load
data,expl=open("story.txt","r").read(),[]          #reading story,from a text file
pygame.mixer.music.load("info.mp3")
pygame.mixer.music.play(-1)  
walkright,char,flare,thrust,enemy_1,enemy_2,enemy_3,enemy_4,x,y,walkleft=[],[],[],[],[],[],[],[],50,50,[]
def show(string,si=1,color=(255,255,255),pos=(0,0)):win.blit(font.render(string,si,color),pos)# A funtion that displays character on screeen
"""for j in data:  #displaying the story
    show(j,color=(0,255,0),pos=(x,y))
    x+=16
    if (x>=450 and j==" ") or j=="%":
        x=50
        y+=30
    if j=="$":break
    time.sleep(.05)
    pygame.display.update()
time.sleep(3)
win.fill((0,0,0))"""
def loadimage(lists,size,path):
    for i in range(size):lists.append(Load(path+str(i)+".png"))
loadimage(walkright,15,"anim/Player/TiltRight/")
loadimage(char,15,"anim/Player/Default/")
loadimage(enemy_1,16,"anim/Enemy/Default/")
loadimage(enemy_2,16,"anim/SpikeyEnemy/Default/")
loadimage(enemy_3,16,"anim/FighterEnemy/Default/")
loadimage(enemy_4,16,"anim/BugEnemy/Default/")
loadimage(thrust,16,"anim/PlayerThrust/Default/")
loadimage(flare,8,"anim/GunFlare/Default/")
loadimage(walkleft,15,"anim/Player/TiltLeft/")
loadimage(expl,8,"anim/Explosion2/Default/")
laser=[Load('anim/PlayerLaser/Default/000.png')]
bulletso,col=pygame.mixer.Sound("pew.ogg"),pygame.mixer.Sound("col.wav") # sound effects
deadso,music=pygame.mixer.Sound("die.wav"),pygame.mixer.music.load("Matt.ogg") #music
pygame.mixer.music.play(-1)
score,health,high_score,i=0,400,60000,0                            
class project(object):
    def __init__(self,x,y):self.x,self.y,self.vel=x,y,30
    def draw(self,win):win.blit(laser[0],(self.x+5,self.y-40))
class actor(object):
    def __init__(self,x,y,width,height,end,image_list,fps=1):
        self.x,self.y,self.width,self.height,self.walk,self.vel=x,y,width,height,0,3
        self.box=(self.x+40,self.y,28,60)
        self.health,self.e,self.ec=1000,0,0
        self.fire=False
        self.image_list,self.fps,self.exp,self.visible=image_list,fps,False,True
    def draw(self,win):
        if self.e>=21:self.e=0
        if self.ec>21 and self.exp==True:
            self.exp,self.visible,self.x,self.y=False,True,randint(0,500),-200
            self.draw(win)
            self.ec,self.e=0,0
        if self.exp:
            win.blit(expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=len(self.image_list)*self.fps: self.walk=0
            win.blit(self.image_list[self.walk//self.fps],(self.x,self.y))
            self.walk+=1
            self.box=(self.x+5,self.y-5,60,80)
    def move(self):
        if self.y<700:self.y+=1
        else:self.x,self.y=randint(0,600),-100
        if self.x>0:self.x+=self.vel
        if self.x>=600:self.vel*=-1
        elif self.x<=0:
            self.x=10
            self.vel*=-1
        if self.visible:
            pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100+5,10))
    def hit(self):
        if self.health>0:self.health-=100
        else:
            deadso.play()     #actual image will be replaced with other
            self.exp,self.health,self.visible,self.visible=True,1000,False,False          #If life will be 0 then explosion will take place
def iscol(t1,t2):
    if t2.visible:
        if t1.box[1]<t2.box[1]+t2.box[3] and t1.box[1]+t1.box[3] >t2.box[1]:
                if t1.box[0]+t1.box[2]>t2.box[0] and t1.box[0]<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:return False
                return True
        else:return False
    else:return False
def istouch(t1,t2):
    if t2.visible:
        if t1.y<t2.box[1]+t2.box[3] and t1.y>t2.box[1] and t2.y>0:
                if t1.x>t2.box[0] and t1.x<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:return False
                return True
        else:return False
    else:return False
def redrawgamewimdow():
    global i
    if i==0:win.blit(Load('000.png'),(0,0))
    elif i==5:win.blit(Load('gameover.png'),(-60,0))
    else:
        win.blit(bg,(0,0))
        show('SCORE:  '+str(score),1,color=(0,255,0),pos=(392,42))
        show('HIGH SCORE:  '+str(high_score),1,color=(0,255,0),pos=(392,82))
        show('AMMO:  '+str(ammo),1,color=(0,255,0),pos=(2,68))
        show('HEALTH BAR',1,color=(0,255,0),pos=(2,10))
        pygame.draw.rect(win,(0,0,255),(4,42,162,14),2)
        pygame.draw.rect(win,(255,0,0),(6,44,health*.4,10))
        man.draw(win)
        for enem in ENEMY:
            enem.draw(win)
            enem.move()
        for bullet in bullets: bullet.draw(win)            
def start():
    global ENEMY,man,health,score,ammo,i
    ENEMY=[actor(200,100,64,64,100,enemy_1),actor(100,40,64,64,450,enemy_2),actor(200,200,64,64,100,enemy_4),actor(0,0,64,64,100,enemy_3),actor(200,0,64,64,100,enemy_2)]
    health,score,ammo,i,man=400,0,1000,10,actor(250, 600, 64, 64,char,15)
start()
shoot,ammo,i,bullets,i,pause,inc,sh,man.vel=0,1000,0,[],0,"off",0,16,8
while True:
    clock.tick(27)
    for event in pygame.event.get():
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_r:
                i=10
                start()
            if event.key==pygame.K_p:
                if pause=="on": pause="off"
                else:pause="on"
        if event.type==pygame.QUIT:run=False
    if pause=="on": continue
    if score>high_score: high_score=score
    if health<0 or ammo<0:
        i,health,man.x,man.y=5,400,250,600
        win.fill((0,0,0))
    for enem in ENEMY:
        if enem.visible and iscol(man,enem):health-=20
    for bullet in bullets:
        for enem in ENEMY:
            if istouch(bullet,enem):
                score+=100
                inc+=1
                ammo+=2
                bullet.y,bullet.x=-550,-550            
        if bullet.y<1000 and bullet.y>-100:bullet.y-=bullet.vel
        else:bullets.remove(bullet)
    ke=pygame.key.get_pressed()
    if ke[pygame.K_SPACE]:
        shoot+=1
        if shoot in range(0,5):
            man.fire=True
            ammo-=1
            bulletso.play()
            if len(bullets)>-5:bullets.append(project(round (man.x+man.width//2-12),round(man.y+man.height//2-25)))
        if shoot>8: shoot=0
    else:man.fire=False
    if ke[pygame.K_LEFT] and man.x>0:
        man.x-=8
        man.image_list=walkleft 
    elif ke[pygame.K_RIGHT] and man.x<600:
        man.x+=8
        man.image_list=walkright
    else:man.image_list=char
    if ke[pygame.K_UP]:man.y-=8
    if ke[pygame.K_DOWN]:man.y+=8
    redrawgamewimdow()
    if health<350 and inc>=50:
        health+=50
        sh,inc=0,0
    if sh<=16 and health:
        show("Health increased",color=(0,255,0),pos=(300,300))
        sh+=1
    pygame.display.update()
pygame.quit()

