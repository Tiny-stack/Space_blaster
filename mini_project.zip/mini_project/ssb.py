import pygame
win=pygame.display.set_mode((700,480))
box=(20,56,28,60)
pygame.draw.rect(win,(255,0,0),(20,56,28,60),2)
pygame.draw.circle(win,(0,0,255),(200,200),50)
pygame.display.update()
