x=10
y=5
print(x%y)
