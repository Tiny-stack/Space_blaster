import pygame     #WE work in the dark ,so that light may exist
from random import randint
import time
pygame.init()
win=pygame.display.set_mode((700,680))
pygame.display.set_caption("My Gamme")
clock=pygame.time.Clock()
walkleft=[pygame.image.load('Animations/Player/TiltLeft/000.png'),pygame.image.load('Animations/Player/TiltLeft/001.png'),pygame.image.load('Animations/Player/TiltLeft/002.png'),pygame.image.load('Animations/Player/TiltLeft/003.png'),pygame.image.load('Animations/Player/TiltLeft/004.png'),pygame.image.load('Animations/Player/TiltLeft/005.png'),pygame.image.load('Animations/Player/TiltLeft/006.png'),pygame.image.load('Animations/Player/TiltLeft/007.png'),pygame.image.load('Animations/Player/TiltLeft/008.png'),pygame.image.load('Animations/Player/TiltLeft/009.png'),pygame.image.load('Animations/Player/TiltLeft/010.png'),pygame.image.load('Animations/Player/TiltLeft/011.png'),pygame.image.load('Animations/Player/TiltLeft/012.png'),pygame.image.load('Animations/Player/TiltLeft/013.png'),pygame.image.load('Animations/Player/TiltLeft/014.png')]
bg=pygame.image.load('4bg.png')
font=pygame.font.SysFont('Algerian',30)
Load,typ=pygame.image.load,pygame.mixer.Sound("key.wav")
data=open("story.txt","r").read()
pygame.mixer.music.load("info.mp3")
pygame.mixer.music.play(-1)  
walkright,char,flare,thrust,enemy_1,enemy_2,enemy_3,enemy_4,x,y=[],[],[],[],[],[],[],[],50,50
def show(string,si=1,color=(255,255,255),pos=(0,0)):win.blit(font.render(string,si,color),pos)
for j in data:
    show(j,color=(0,255,0),pos=(x,y))
    x+=16
    if (x>=450 and j==" ") or j=="%":
        x=50
        y+=30
    if j=="$":break
    time.sleep(.05)
    pygame.display.update()
time.sleep(3)
win.fill((0,0,0))
for i in range(10): 
    walkright.append(Load("Animations/Player/TiltRight/"+'00'+str(i)+".png"))
    char.append(Load("Animations/Player/Default/"+"00"+str(i)+".png"))
for i in range(10,15):
    walkright.append(Load("Animations/Player/TiltRight/"+'0'+str(i)+".png"))
    char.append(Load("Animations/Player/Default/"+'0'+str(i)+".png"))
for i in range(10): 
    enemy_1.append(Load('Animations/Enemy/Default/'+'00'+str(i)+".png"))
    enemy_2.append(Load('Animations/SpikeyEnemy/Default/'+'00'+str(i)+".png"))
    enemy_3.append(Load('Animations/FighterEnemy/Default/'+'00'+str(i)+".png"))
    enemy_4.append(Load('Animations/BugEnemy/Default/'+'00'+str(i)+'.png'))
    thrust.append(Load("Animations/PlayerThrust/Default/"+"00"+str(i)+".png"))
for i in range(10,16):
    enemy_1.append(Load('Animations/Enemy/Default/'+'0'+str(i)+".png"))
    enemy_2.append(Load('Animations/SpikeyEnemy/Default/'+'0'+str(i)+".png"))
    enemy_3.append(Load('Animations/FighterEnemy/Default/'+'0'+str(i)+".png"))
    enemy_4.append(Load('Animations/BugEnemy/Default/'+'0'+str(i)+'.png'))
    thrust.append(Load("Animations/PlayerThrust/Default/"+"0"+str(i)+".png"))
    enemy_1.append(Load('Animations/Enemy/Default/'+'0'+str(i)+".png"))
    thrust.append(Load("Animations/PlayerThrust/Default/"+'0'+str(i)+".png"))
for i in range(8): flare.append(Load('Animations/GunFlare/Default/00'+str(i)+".png"))
laser=[Load('Animations/PlayerLaser/Default/000.png')]
bulletso,col=pygame.mixer.Sound("pew.ogg"),pygame.mixer.Sound("col.wav")
deadso,music=pygame.mixer.Sound("die.wav"),pygame.mixer.music.load("Matt.ogg")
pygame.mixer.music.play(-1)
score,health,high_score=0,400,60000                            
class actor(object):
    def __init__(self,x,y,width,height,image_list,fps):
        self.x,self.y,self.f,self.width,self.height,self.vel,self.walk=x,y,0,width,height,8,0
        self.fire,self.t,self.box=False,0,(self.x,self.y,80,100)
        self.image_list,self.fps=image_list,fps     
    def draw(self,win):
        if self.fps>=45:self.fps=0
        if self.t>=15:self.t=0
        win.blit(thrust[self.t],(self.x+5,self.y+70))
        self.t+=1
        if self.f>=7:self.f=0
        win.blit(self.image_list[self.fps//3],(self.x,self.y))
        self.fps+=1
        if self.fire:
            win.blit(flare[self.f],(self.x+5,self.y-40))
            self.f+=1
        self.box=(self.x,self.y,80,100)
class project(object):
    def __init__(self,x,y):self.x,self.y,self.vel=x,y,30
    def draw(self,win):win.blit(laser[0],(self.x+5,self.y-40))
class enemy(object):
    expl=[pygame.image.load('Animations/Explosion2/Default/000.png'),pygame.image.load('Animations/Explosion2/Default/001.png'),pygame.image.load('Animations/Explosion2/Default/002.png'),pygame.image.load('Animations/Explosion2/Default/003.png'),pygame.image.load('Animations/Explosion2/Default/004.png'),pygame.image.load('Animations/Explosion2/Default/005.png'),pygame.image.load('Animations/Explosion2/Default/006.png'),pygame.image.load('Animations/Explosion2/Default/007.png')]
    def __init__(self,x,y,width,height,end,image_list,fps=1):
        self.x,self.y,self.width,self.height,self.walk,self.vel=x,y,width,height,0,3
        self.box=(self.x+40,self.y,28,60)
        self.health,self.e,self.ec=1000,0,0
        self.image_list,self.fps,self.exp,self.visible=image_list,fps,False,True
    def draw(self,win):
        self.move()
        if self.e>=21:self.e=0
        if self.ec>21 and self.exp==True:
            self.exp,self.visible,self.x,self.y=False,True,randint(0,500),-200
            self.draw(win)
            self.ec,self.e=0,0
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=len(self.image_list)*self.fps: self.walk=0
            win.blit(self.image_list[self.walk//self.fps],(self.x,self.y))
            self.walk+=1
            self.box=(self.x+5,self.y-5,60,80)
            pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
    def move(self):
        if self.y<700:self.y+=1
        else:self.x,self.y=randint(0,600),-100
        if self.x>0:self.x+=self.vel
        if self.x>=600:self.vel*=-1
        elif self.x<=0:
            self.x=10
            self.vel*=-1        
    def hit(self):
        if self.health>0:self.health-=100
        else:
            deadso.play()
            self.visible=False       #actual image will be replaced with other
            self.exp,self.health,self.visible=True,1000,False           #If life will be 0 then explosion will take place
    pygame.display.update()
def iscol(t1,t2):
    if t2.visible:
        if t1.box[1]<t2.box[1]+t2.box[3] and t1.box[1]+t1.box[3] >t2.box[1]:
                if t1.box[0]+t1.box[2]>t2.box[0] and t1.box[0]<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:return False
                return True
        else:return False
    else:return False
def istouch(t1,t2):
    if t2.visible:
        if t1.y<t2.box[1]+t2.box[3] and t1.y>t2.box[1] and t2.y>0:
                if t1.x>t2.box[0] and t1.x<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:return False
                return True
        else:return False
    else:return False
i=0
def redrawgamewimdow():
    global i
    if i==0:win.blit(Load('000.png'),(0,0))
    elif i==5:win.blit(Load('gameover.png'),(0,0))
    else:
        win.blit(bg,(0,0))
        show('SCORE:  '+str(score),1,color=(0,255,0),pos=(392,42))
        show('HIGH SCORE:  '+str(high_score),1,color=(0,255,0),pos=(392,82))
        show('AMMO:  '+str(ammo),1,color=(0,255,0),pos=(2,68))
        show('HEALTH BAR',1,color=(0,255,0),pos=(2,10))
        pygame.draw.rect(win,(0,0,255),(4,42,162,14),2)
        pygame.draw.rect(win,(255,0,0),(6,44,health*.4,10))
        man.draw(win)
        for enem in ENEMY:enem.draw(win)
        for bullet in bullets: bullet.draw(win)            
def start():
    global ENEMY,man,health,score,ammo,i
    ENEMY=[enemy(200,100,64,64,100,enemy_1),enemy(100,40,64,64,450,enemy_2),enemy(200,200,64,64,100,enemy_4),enemy(0,0,64,64,100,enemy_3),enemy(200,0,64,64,100,enemy_2)]
    man = actor(250, 600, 64, 64,char,15)
    health,score,ammo,i=400,0,1000,10
start()
shoot,ammo,i,bullets,i=0,1000,0,[],0
while True:
    clock.tick(27)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:run=False
    if score>high_score: high_score=score
    if health<0 or ammo<0:i,health,man.x,man.y=5,400,250,600     
    for enem in ENEMY:
        if enem.visible and iscol(man,enem):
            score-=50
            ammo-=20
            health-=20
            col.play()
    for bullet in bullets:
        for enem in ENEMY:
            if istouch(bullet,enem):
                score+=100
                ammo+=2
                bullet.y,bullet.x=-550,-550            
        if bullet.y<1000 and bullet.y>-100:bullet.y-=bullet.vel
        else:bullets.remove(bullet)
    ke=pygame.key.get_pressed()
    if ke[pygame.K_SPACE]:
        ammo-=1
        shoot+=1
        if shoot in range(0,5):
            man.fire=True
            bulletso.play()
            if len(bullets)>-5:bullets.append(project(round (man.x+man.width//2-12),round(man.y+man.height//2-25)))
        if shoot>8: shoot=0
        if i==0 or i==5:start()
    else:man.fire=False
    if ke[pygame.K_LEFT] and man.x>0:
        man.x-=man.vel
        man.image_list=walkleft                    #if any idea will come then it will be updated soon //(Updated)
    elif ke[pygame.K_RIGHT] and man.x<600:
        man.x+=man.vel
        man.image_list=walkright
    else:man.image_list=char
    if ke[pygame.K_UP]:man.y-=man.vel
    else: man.thrust=False
    if ke[pygame.K_DOWN]:man.y+=man.vel
    redrawgamewimdow()
    pygame.display.update()
pygame.quit()

