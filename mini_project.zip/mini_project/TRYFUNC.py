import pygame
from random import randint
import math
#..........................................WELCOME TO TINYSOFT.......................................#
pygame.init()
win=pygame.display.set_mode((700,680))
pygame.display.set_caption("My Gamme")
#setting screen completed here
clock=pygame.time.Clock()
#Loading image and sound
char=[pygame.image.load('Animations/Player/Default/000.png'),pygame.image.load('Animations/Player/Default/001.png'),pygame.image.load('Animations/Player/Default/002.png'),pygame.image.load('Animations/Player/Default/003.png'),pygame.image.load('Animations/Player/Default/004.png'),pygame.image.load('Animations/Player/Default/005.png'),pygame.image.load('Animations/Player/Default/006.png'),pygame.image.load('Animations/Player/Default/007.png'),pygame.image.load('Animations/Player/Default/008.png'),pygame.image.load('Animations/Player/Default/009.png'),pygame.image.load('Animations/Player/Default/010.png'),pygame.image.load('Animations/Player/Default/011.png'),pygame.image.load('Animations/Player/Default/012.png'),pygame.image.load('Animations/Player/Default/013.png'),pygame.image.load('Animations/Player/Default/014.png')]
walkleft=[pygame.image.load('Animations/Player/TiltLeft/000.png'),pygame.image.load('Animations/Player/TiltLeft/001.png'),pygame.image.load('Animations/Player/TiltLeft/002.png'),pygame.image.load('Animations/Player/TiltLeft/003.png'),pygame.image.load('Animations/Player/TiltLeft/004.png'),pygame.image.load('Animations/Player/TiltLeft/005.png'),pygame.image.load('Animations/Player/TiltLeft/006.png'),pygame.image.load('Animations/Player/TiltLeft/007.png'),pygame.image.load('Animations/Player/TiltLeft/008.png'),pygame.image.load('Animations/Player/TiltLeft/009.png'),pygame.image.load('Animations/Player/TiltLeft/010.png'),pygame.image.load('Animations/Player/TiltLeft/011.png'),pygame.image.load('Animations/Player/TiltLeft/012.png'),pygame.image.load('Animations/Player/TiltLeft/013.png'),pygame.image.load('Animations/Player/TiltLeft/014.png')]
bg=pygame.image.load('000.png')
Load=pygame.image.load
act="Animations/Player/TiltRight/"
walkright=[]
for i in range(10): walkright.append(Load(act+'00'+str(i)+".png"))
for i in range(10,15): walkright.append(Load(act+'0'+str(i)+".png"))
flare=[]
for i in range(8): flare.append(Load('Animations/GunFlare/Default/00'+str(i)+".png"))
thrust=[pygame.image.load('Animations/PlayerThrust/Default/000.png'),pygame.image.load('Animations/PlayerThrust/Default/001.png'),pygame.image.load('Animations/PlayerThrust/Default/002.png'),pygame.image.load('Animations/PlayerThrust/Default/003.png'),pygame.image.load('Animations/PlayerThrust/Default/003.png'),pygame.image.load('Animations/PlayerThrust/Default/004.png'),pygame.image.load('Animations/PlayerThrust/Default/005.png'),pygame.image.load('Animations/PlayerThrust/Default/006.png'),pygame.image.load('Animations/PlayerThrust/Default/007.png'),pygame.image.load('Animations/PlayerThrust/Default/008.png'),pygame.image.load('Animations/PlayerThrust/Default/009.png'),pygame.image.load('Animations/PlayerThrust/Default/010.png'),pygame.image.load('Animations/PlayerThrust/Default/011.png'),pygame.image.load('Animations/PlayerThrust/Default/012.png'),pygame.image.load('Animations/PlayerThrust/Default/013.png'),pygame.image.load('Animations/PlayerThrust/Default/014.png'),pygame.image.load('Animations/PlayerThrust/Default/015.png')]
laser=[Load('Animations/PlayerLaser/Default/000.png')]
bulletso=pygame.mixer.Sound("pew.ogg")
rocket=pygame.mixer.Sound("rocket.ogg")
col=pygame.mixer.Sound("col.wav")
deadso=pygame.mixer.Sound("die.wav")
music=pygame.mixer.music.load("Matt.ogg")
mis=[Load('Animations/PlayerRocket/Default/000.png')]
score,health=0,400       
f1=open("high_score.txt","r")                     
high_score=f1.read()
high_score=int(high_score)
#.....................................................................................................#        
#.....................................................................................................#        
class actor(object):
    def __init__(self,x,y,width,height):
        self.x=x
        self.visible=True
        self.thrust=False
        self.f=0
        self.y=y
        self.width=width
        self.height=height
        self.left=False
        self.right=False
        self.vel=6
        self.isjump=False
        self.jump=10
        self.walk=0
        self.standing=True
        self.fire=False
        self.t=0
        self.h=200
        self.box=(self.x+20,self.y,28,60)
        self.s=0
#_________________________________________________________________________________________________________#       
    def draw(self,win):
        if self.s>=45:
            self.s=0
        if self.t>=15:
            self.t=0
        if self.thrust:
            win.blit(thrust[self.t],(self.x+5,self.y+70))
            self.t+=1
        if self.walk >=45:
            self.walk=0
        if self.f>=7:
            self.f=0
        if self.left:
            win.blit(walkleft[self.walk//3],(self.x,self.y))
            self.walk+=1
        elif self.right:
            win.blit(walkright[self.walk//3],(self.x,self.y))
            self.walk+=1
        if self.standing:
            win.blit(char[self.s//3],(self.x,self.y))
            self.s+=1
        if self.fire:
            win.blit(flare[self.f],(self.x+5,self.y-40))
            self.f+=1
        self.box=(self.x,self.y,80,100)
        pygame.draw.rect(win,(255,0,0),self.box,20)
#_____________________________________________________________________________________________________#
    def hit(self):
        self.isjump=False
        self.jump=10
        self.walk=0
        pygame.display.update()
        i=0
#....................................................................................................#        
class project(object):
    def __init__(self,x,y,radius,color,facing):
        self.x=x
        self.y=y
        self.radius=radius
        self.color=color
        self.vel=30
    def draw(self,win):
        win.blit(laser[0],(self.x+5,self.y-40))
#......................................................................................................#
class enemy(object):
    walkright=[pygame.image.load('Animations/Enemy/Default/001.png'),pygame.image.load('Animations/Enemy/Default/002.png'),pygame.image.load('Animations/Enemy/Default/003.png'),pygame.image.load('Animations/Enemy/Default/004.png'),pygame.image.load('Animations/Enemy/Default/005.png'),pygame.image.load('Animations/Enemy/Default/006.png'),pygame.image.load('Animations/Enemy/Default/007.png'),pygame.image.load('Animations/Enemy/Default/008.png'),pygame.image.load('Animations/Enemy/Default/009.png'),pygame.image.load('Animations/Enemy/Default/010.png'),pygame.image.load('Animations/Enemy/Default/011.png'),pygame.image.load('Animations/Enemy/Default/012.png'),pygame.image.load('Animations/Enemy/Default/013.png'),pygame.image.load('Animations/Enemy/Default/014.png'),pygame.image.load('Animations/Enemy/Default/015.png')]
    bug3=[pygame.image.load('Animations/SpikeyEnemy/Default/000.png'),pygame.image.load('Animations/SpikeyEnemy/Default/001.png'),pygame.image.load('Animations/SpikeyEnemy/Default/002.png'),pygame.image.load('Animations/SpikeyEnemy/Default/003.png'),pygame.image.load('Animations/SpikeyEnemy/Default/004.png'),pygame.image.load('Animations/SpikeyEnemy/Default/005.png'),pygame.image.load('Animations/SpikeyEnemy/Default/006.png'),pygame.image.load('Animations/SpikeyEnemy/Default/007.png'),pygame.image.load('Animations/SpikeyEnemy/Default/008.png'),pygame.image.load('Animations/SpikeyEnemy/Default/009.png'),pygame.image.load('Animations/SpikeyEnemy/Default/010.png'),pygame.image.load('Animations/SpikeyEnemy/Default/011.png'),pygame.image.load('Animations/SpikeyEnemy/Default/012.png'),pygame.image.load('Animations/SpikeyEnemy/Default/013.png'),pygame.image.load('Animations/SpikeyEnemy/Default/014.png'),pygame.image.load('Animations/SpikeyEnemy/Default/015.png')]
    bug2=[pygame.image.load('Animations/FighterEnemy/Default/000.png'),pygame.image.load('Animations/FighterEnemy/Default/001.png'),pygame.image.load('Animations/FighterEnemy/Default/002.png'),pygame.image.load('Animations/FighterEnemy/Default/003.png'),pygame.image.load('Animations/FighterEnemy/Default/004.png'),pygame.image.load('Animations/FighterEnemy/Default/005.png'),pygame.image.load('Animations/FighterEnemy/Default/006.png'),pygame.image.load('Animations/FighterEnemy/Default/007.png'),pygame.image.load('Animations/FighterEnemy/Default/008.png'),pygame.image.load('Animations/FighterEnemy/Default/009.png'),pygame.image.load('Animations/FighterEnemy/Default/010.png'),pygame.image.load('Animations/FighterEnemy/Default/011.png'),pygame.image.load('Animations/FighterEnemy/Default/012.png'),pygame.image.load('Animations/FighterEnemy/Default/013.png'),pygame.image.load('Animations/FighterEnemy/Default/014.png'),pygame.image.load('Animations/FighterEnemy/Default/015.png')]
    bug=[pygame.image.load('Animations/BugEnemy/Default/001.png'),pygame.image.load('Animations/BugEnemy/Default/002.png'),pygame.image.load('Animations/BugEnemy/Default/003.png'),pygame.image.load('Animations/BugEnemy/Default/004.png'),pygame.image.load('Animations/BugEnemy/Default/005.png'),pygame.image.load('Animations/BugEnemy/Default/006.png'),pygame.image.load('Animations/BugEnemy/Default/007.png'),pygame.image.load('Animations/BugEnemy/Default/008.png'),pygame.image.load('Animations/BugEnemy/Default/009.png'),pygame.image.load('Animations/BugEnemy/Default/010.png'),pygame.image.load('Animations/BugEnemy/Default/011.png'),pygame.image.load('Animations/BugEnemy/Default/012.png'),pygame.image.load('Animations/BugEnemy/Default/013.png'),pygame.image.load('Animations/BugEnemy/Default/014.png'),pygame.image.load('Animations/BugEnemy/Default/015.png')]
    expl=[pygame.image.load('Animations/Explosion2/Default/000.png'),pygame.image.load('Animations/Explosion2/Default/001.png'),pygame.image.load('Animations/Explosion2/Default/002.png'),pygame.image.load('Animations/Explosion2/Default/003.png'),pygame.image.load('Animations/Explosion2/Default/004.png'),pygame.image.load('Animations/Explosion2/Default/005.png'),pygame.image.load('Animations/Explosion2/Default/006.png'),pygame.image.load('Animations/Explosion2/Default/007.png')]
    expm=[pygame.image.load('Animations/Explosion3/Default/000.png'),pygame.image.load('Animations/Explosion3/Default/001.png'),pygame.image.load('Animations/Explosion3/Default/002.png'),pygame.image.load('Animations/Explosion3/Default/003.png'),pygame.image.load('Animations/Explosion3/Default/004.png'),pygame.image.load('Animations/Explosion3/Default/005.png'),pygame.image.load('Animations/Explosion3/Default/006.png'),pygame.image.load('Animations/Explosion3/Default/007.png'),pygame.image.load('Animations/Explosion3/Default/008.png'),pygame.image.load('Animations/Explosion3/Default/009.png'),pygame.image.load('Animations/Explosion3/Default/010.png'),pygame.image.load('Animations/Explosion3/Default/011.png'),pygame.image.load('Animations/Explosion3/Default/012.png'),pygame.image.load('Animations/Explosion3/Default/013.png'),pygame.image.load('Animations/Explosion3/Default/014.png'),pygame.image.load('Animations/Explosion3/Default/015.png'),pygame.image.load('Animations/Explosion3/Default/016.png'),pygame.image.load('Animations/Explosion3/Default/017.png'),pygame.image.load('Animations/Explosion3/Default/018.png'),pygame.image.load('Animations/Explosion3/Default/019.png'),pygame.image.load('Animations/Explosion3/Default/020.png'),pygame.image.load('Animations/Explosion3/Default/021.png'),pygame.image.load('Animations/Explosion3/Default/022.png'),pygame.image.load('Animations/Explosion3/Default/023.png'),pygame.image.load('Animations/Explosion3/Default/024.png'),pygame.image.load('Animations/Explosion3/Default/025.png'),pygame.image.load('Animations/Explosion3/Default/026.png'),pygame.image.load('Animations/Explosion3/Default/027.png'),pygame.image.load('Animations/Explosion3/Default/028.png'),pygame.image.load('Animations/Explosion3/Default/029.png'),pygame.image.load('Animations/Explosion3/Default/030.png'),pygame.image.load('Animations/Explosion3/Default/031.png'),pygame.image.load('Animations/Explosion3/Default/032.png'),pygame.image.load('Animations/Explosion3/Default/033.png'),pygame.image.load('Animations/Explosion3/Default/034.png'),pygame.image.load('Animations/Explosion3/Default/035.png'),pygame.image.load('Animations/Explosion3/Default/036.png'),pygame.image.load('Animations/Explosion3/Default/037.png'),pygame.image.load('Animations/Explosion3/Default/038.png'),pygame.image.load('Animations/Explosion3/Default/039.png')]
#____________________________________________________________________________________________________#
    def __init__(self,x,y,width,height,end):
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.end=end
        self.walk=0
        self.vel=3
        self.path=[self.x,self.y]
        self.box=(self.x+40,self.y,28,60)
        self.health=1000
        self.visible=True
        self.exp=False
        self.e=0
        self.ec=0
        self.right=True
        self.left=False
#_____________________________________________________________________________________________________#
    def draw(self,win):
        self.move()
        if self.e>=21:
            self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=-200
            self.draw2(win)
            self.ec=0
            self.e=0
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=15: self.walk=0
            if self.vel>0:
                win.blit(self.walkright[self.walk],(self.x,self.y))
                self.walk+=1
            else:
                win.blit(self.walkright[self.walk],(self.x,self.y))
                self.walk+=1
            pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
#____________________________________________________________________________________________________#
    def draw2(self,win):
        self.move()
        if self.e>=21:self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=-150
            self.draw2(win)
            self.ec=0
            self.e=0
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=15: self.walk=0
            if self.vel>0:
                win.blit(self.bug[self.walk],(self.x,self.y))
                self.walk+=1
            else:
                win.blit(self.bug[self.walk],(self.x,self.y))
                self.walk+=1
            pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
            #pygame.draw.rect(win,(255,0,0),self.box,2)
#_____________________________________________________________________________________________________#        
    def draw3(self,win):
        self.move()
        if self.e>=21: self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=-200
            self.draw2(win)
            self.ec=0
            self.e=0
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=45:
                self.walk=0
            win.blit(self.bug2[self.walk//3],(self.x,self.y))
            self.walk+=1
            pygame.draw.rect(win,(255,0,0),(self.box[0]+20,self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
            #pygame.draw.rect(win,(255,0,0),self.box,2)
#____________________________________________________________________________________________________#
    def draw4(self,win):
        self.move()
        if self.e>=21:
            self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=-100
            self.draw2(win)
            self.ec=0
            self.e=0
        if self.exp:                    #if explosion will happen the this image would be appear
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=45:
                self.walk=0
            win.blit(self.bug3[self.walk//3],(self.x,self.y))
            self.walk+=1
            pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
            #pygame.draw.rect(win,(255,0,0),self.box,2)
#_____________________________________________________________________________________________________#
    def move(self):
        if self.y<700:
            self.y+=1
        else:
            self.x=randint(0,600)
            self.y=-100
        if self.x>0:
            self.x+=self.vel
        if self.x>=600:
            self.vel*=-1
            self.left=True
            self.right=False
        elif self.x<=0:
            self.right=True
            self.left=False
            self.x=10
            self.vel*=-1
#_____________________________________________________________________________________________________#        
    def hit(self):
        if self.health>0:
            self.health-=100
        else:
            deadso.play()
            self.visible=False       #actual image will be replaced with other
            self.exp=True            #If life will be 0 then explosion will take place
            self.health=1000         #and health will be initialized with 1000 again
    pygame.display.update()
def iscol(t1,t2):
    if t2.visible:
        if t1.box[1]<t2.box[1]+t2.box[3] and t1.box[1]+t1.box[3] >t2.box[1]:
                if t1.box[0]+t1.box[2]>t2.box[0] and t1.box[0]<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:
                    return False
                return True
        else:
            return False
    else:
        return False
def istouch(t1,t2):
    if t2.visible:
        if t1.y<t2.box[1]+t2.box[3] and t1.y>t2.box[1] and t2.y>0:
                if t1.x>t2.box[0] and t1.x<t2.box[0]+t2.box[2]:
                    t2.hit()
                    return True
                else:
                    return False
                return True
        else:
            return False
    else:
        return False
#.....................................................................................................#
def redrawgamewimdow():
    win.blit(bg,(0,0))
    text,tex=font.render('SCORE:'+str(score),1,(0,255,0)),font.render('SCORE:'+str(score),1,(0,0,255))
    win.blit(tex,(390,40))
    win.blit(text,(392,42))
    text,tex=font.render('HIGH SCORE:'+str(high_score),1,(0,255,0)),font.render('HIGH SCORE:'+str(high_score),1,(0,0,255))
    win.blit(tex,(390,80))
    win.blit(text,(392,82))
    text,tex=font.render('AMMO:'+str(ammo),1,(0,255,0)),font.render('AMMO:'+str(ammo),1,(0,0,255))
    win.blit(tex,(0,80))
    win.blit(text,(2,82))
    text,tex=font.render('HEALTH:'+str(health),1,(0,255,0)),font.render('HEALTH:'+str(health),1,(0,0,255))
    win.blit(tex,(0,40))
    win.blit(text,(2,42))
    man.draw(win)
    e.draw(win)
    e2.draw2(win)
    e3.draw(win)
    e4.draw2(win)
    e5.draw3(win)
    e6.draw4(win)
    for bullet in bullets: bullet.draw(win)
    pygame.display.update()
pygame.mixer.music.play(-1)
#...............................................................................................                
font=pygame.font.SysFont('AmericanTypewriter cs',30)
man = actor(250, 600, 64, 64)
e=enemy(100,40,64,64,450)
bullets=[]
e2=enemy(200,100,64,64,100)
e3=enemy(200,0,64,64,100)
e4=enemy(0,0,64,64,100)
e5=enemy(200,200,64,64,100)
e6=enemy(-200,0,64,64,100)
run,shoot,ammo,i=True,0,1000,0
#.......................................................................................................#
#..........................................MAIN LOOP..................................................#    
while run:
    clock.tick(27)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    if score>high_score: high_score=score
    z=randint(1,20)
    if health<0 or ammo<0:
        i,health,e.x,e.y,e2.x,e2.y,e3.x,e3.y,e4.x,e4.y=5,400,100,40,200,-50,200,0,0,0
        e5.x=100
        e5.y=-200
        e6.x=500
        e6.y=-300
        man.x=250
        man.y=600
        high_score=str(high_score)
        f2=open("high_score.txt","w")
        f2.write(high_score)
        high_score=int(high_score)
        f2.close()
#..............................Collision Enemy and Space SHip.......................................#        
    if (e.visible==True or e2.visible==True or e3.visible==True or e4.visible==True or e5.visible==True or e6.visible==True) and i!=5:
        if iscol(man,e) or iscol(man,e2) or iscol(man,e3) or iscol(man,e4) or iscol(man,e5) or iscol(man,e6):
            score-=50
            ammo-=20
            health-=20
            col.play()
            man.hit()
#.................................................................................................#    
#.........................Collision Bullet and enemies......................................#
    for bullet in bullets:
        if istouch(bullet,e) or istouch(bullet,e2) or istouch(bullet,e3) or istouch(bullet,e4) or istouch(bullet,e5) or istouch(bullet,e6):
            score+=100
            ammo+=2
            bullet.y,bullet.x=-550,-550
#...............................................................................................#
#..............................MOvemnt of Bullet................................................#            
        if bullet.y<1000 and bullet.y>-100:bullet.y-=bullet.vel
        else:bullet.x,bullet.y=-550,-550
#...........................................Check Key Press.....................................#
#...........................................Fire Bullets........................................#
    ke=pygame.key.get_pressed()
    if ke[pygame.K_SPACE]:
        bulletso.play()
        ammo-=1
        man.fire=True
        if i==0 or i==5:health,score,ammo,bg,i=400,0,1000,Load('backg.gif'),10
        if len(bullets)>-5:bullets.append(project(round (man.x+man.width//2-12),round(man.y+man.height//2-25),6,(0,0,0),1))
    else:man.fire=False
#.....................................................................................................#
#........................................MoveMent of Space Ship........................................#
    if ke[pygame.K_LEFT] and man.x>0:
        man.x-=man.vel
        man.left=True
        man.right=False
        man.standing=False                     #if any idea will come then it will be updated soon
    elif ke[pygame.K_RIGHT] and man.x<600:
        man.x+=man.vel
        man.right=True
        man.left=False
        man.standing=False
    else:man.right,man.left,man.standing=False,False,True
    if ke[pygame.K_UP]:
        man.thrust=True
        man.y-=man.vel
    else: man.thrust=False
    if ke[pygame.K_DOWN]:man.y+=man.vel
#............................................................................#       
#............................................................................#
    if i==10:redrawgamewimdow()
    elif i==5:
        sc=score
        bg=pygame.image.load('002.png')
        win.blit(bg,(0,200))
        text=font.render('YOUR SCORE WAS:'+str(sc),6,(0,0,255))
        win.blit(text,(400,280))
    if i==0:win.blit(bg,(0,200))
    pygame.display.update()
pygame.quit()
#devoloper dr. Tiny a dreamer thanks for visiting


