import pygame
from random import*
import math
#..........................................WELCOME TO TINYSOFT.......................................#
pygame.init()
win=pygame.display.set_mode((700,680))
pygame.display.set_caption("My Gamme")
clock=pygame.time.Clock()
char=[pygame.image.load('Animations/Player/Default/000.png'),pygame.image.load('Animations/Player/Default/001.png'),pygame.image.load('Animations/Player/Default/002.png'),pygame.image.load('Animations/Player/Default/003.png'),pygame.image.load('Animations/Player/Default/004.png'),pygame.image.load('Animations/Player/Default/005.png'),pygame.image.load('Animations/Player/Default/006.png'),pygame.image.load('Animations/Player/Default/007.png'),pygame.image.load('Animations/Player/Default/008.png'),pygame.image.load('Animations/Player/Default/009.png'),pygame.image.load('Animations/Player/Default/010.png'),pygame.image.load('Animations/Player/Default/011.png'),pygame.image.load('Animations/Player/Default/012.png'),pygame.image.load('Animations/Player/Default/013.png'),pygame.image.load('Animations/Player/Default/014.png')]
walkleft=[pygame.image.load('Animations/Player/TiltLeft/000.png'),pygame.image.load('Animations/Player/TiltLeft/001.png'),pygame.image.load('Animations/Player/TiltLeft/002.png'),pygame.image.load('Animations/Player/TiltLeft/003.png'),pygame.image.load('Animations/Player/TiltLeft/004.png'),pygame.image.load('Animations/Player/TiltLeft/005.png'),pygame.image.load('Animations/Player/TiltLeft/006.png'),pygame.image.load('Animations/Player/TiltLeft/007.png'),pygame.image.load('Animations/Player/TiltLeft/008.png'),pygame.image.load('Animations/Player/TiltLeft/009.png'),pygame.image.load('Animations/Player/TiltLeft/010.png'),pygame.image.load('Animations/Player/TiltLeft/011.png'),pygame.image.load('Animations/Player/TiltLeft/012.png'),pygame.image.load('Animations/Player/TiltLeft/013.png'),pygame.image.load('Animations/Player/TiltLeft/014.png')]
bg=pygame.image.load('000.png')
walkright=[pygame.image.load('Animations/Player/TiltRight/000.png'),pygame.image.load('Animations/Player/TiltRight/001.png'),pygame.image.load('Animations/Player/TiltRight/002.png'),pygame.image.load('Animations/Player/TiltRight/003.png'),pygame.image.load('Animations/Player/TiltRight/004.png'),pygame.image.load('Animations/Player/TiltRight/005.png'),pygame.image.load('Animations/Player/TiltRight/006.png'),pygame.image.load('Animations/Player/TiltRight/007.png'),pygame.image.load('Animations/Player/TiltRight/008.png'),pygame.image.load('Animations/Player/TiltRight/009.png'),pygame.image.load('Animations/Player/TiltRight/010.png'),pygame.image.load('Animations/Player/TiltRight/011.png'),pygame.image.load('Animations/Player/TiltRight/012.png'),pygame.image.load('Animations/Player/TiltRight/013.png'),pygame.image.load('Animations/Player/TiltRight/014.png')]
flare=[pygame.image.load('Animations/GunFlare/Default/001.png'),pygame.image.load('Animations/GunFlare/Default/002.png'),pygame.image.load('Animations/GunFlare/Default/003.png'),pygame.image.load('Animations/GunFlare/Default/004.png'),pygame.image.load('Animations/GunFlare/Default/005.png'),pygame.image.load('Animations/GunFlare/Default/006.png'),pygame.image.load('Animations/GunFlare/Default/007.png')]
thrust=[pygame.image.load('Animations/PlayerThrust/Default/000.png'),pygame.image.load('Animations/PlayerThrust/Default/001.png'),pygame.image.load('Animations/PlayerThrust/Default/002.png'),pygame.image.load('Animations/PlayerThrust/Default/003.png'),pygame.image.load('Animations/PlayerThrust/Default/003.png'),pygame.image.load('Animations/PlayerThrust/Default/004.png'),pygame.image.load('Animations/PlayerThrust/Default/005.png'),pygame.image.load('Animations/PlayerThrust/Default/006.png'),pygame.image.load('Animations/PlayerThrust/Default/007.png'),pygame.image.load('Animations/PlayerThrust/Default/008.png'),pygame.image.load('Animations/PlayerThrust/Default/009.png'),pygame.image.load('Animations/PlayerThrust/Default/010.png'),pygame.image.load('Animations/PlayerThrust/Default/011.png'),pygame.image.load('Animations/PlayerThrust/Default/012.png'),pygame.image.load('Animations/PlayerThrust/Default/013.png'),pygame.image.load('Animations/PlayerThrust/Default/014.png'),pygame.image.load('Animations/PlayerThrust/Default/015.png')]
laser=[pygame.image.load('Animations/PlayerLaser/Default/000.png')]
music=pygame.mixer.music.load("Matt.ogg")

bulletso=pygame.mixer.Sound("pew.ogg")
col=pygame.mixer.Sound("col.wav")
deadso=pygame.mixer.Sound("die.wav")
score=0       
health=400    
    
class actor(object):
    def __init__(self,x,y,width,height):
        self.x=x
        self.visible=True
        self.thrust=False
        self.f=0
        self.y=y
        self.width=width
        self.height=height
        self.left=False
        self.right=False
        self.vel=10
        self.isjump=False
        self.jump=10
        self.walk=0
        self.standing=True
        self.fire=False
        self.t=0
        self.h=200
        self.box=(self.x+20,self.y,28,60)
        
    def draw(self,win):
        if self.t>=15:
            self.t=0
        if self.thrust:
            win.blit(thrust[self.t],(self.x+5,self.y+70))
            self.t+=1
        if self.walk >=45:
            self.walk=0
        
        if self.f>=7:
            self.f=0
        
           
        if self.left:
            win.blit(walkleft[self.walk//3],(self.x,self.y))
            self.walk+=1
        elif self.right:
            win.blit(walkright[self.walk//3],(self.x,self.y))
            self.walk+=1
        else:
            win.blit(char[self.walk//3],(self.x,self.y))
            self.walk+=1

        if self.fire:
            win.blit(flare[self.f],(self.x+5,self.y-40))
            self.f+=1
        
        self.box=(self.x,self.y,80,100)
        #pygame.draw.rect(win,(255,0,0),self.box,2)
    def hit(self):
        self.isjump=False
        self.jump=10
        self.walk=0
        font1=pygame.font.SysFont('comicsans',100)
        text=font1.render('-5',1,(255,0,0))
        win.blit(text,(250-(text.get_width()/2),200))
        pygame.display.update()
        i=0
        
class project(object):
    def __init__(self,x,y,radius,color,facing):
        self.x=x
        self.y=y
        self.radius=radius
        self.color=color
        self.facing=facing
        self.vel=24*facing
    def draw(self,win):
        win.blit(laser[0],(self.x+5,self.y-40))
class enemy(object):
    walkright=[pygame.image.load('Animations/Enemy/Default/001.png'),pygame.image.load('Animations/Enemy/Default/002.png'),pygame.image.load('Animations/Enemy/Default/003.png'),pygame.image.load('Animations/Enemy/Default/004.png'),pygame.image.load('Animations/Enemy/Default/005.png'),pygame.image.load('Animations/Enemy/Default/006.png'),pygame.image.load('Animations/Enemy/Default/007.png'),pygame.image.load('Animations/Enemy/Default/008.png'),pygame.image.load('Animations/Enemy/Default/009.png'),pygame.image.load('Animations/Enemy/Default/010.png'),pygame.image.load('Animations/Enemy/Default/011.png'),pygame.image.load('Animations/Enemy/Default/012.png'),pygame.image.load('Animations/Enemy/Default/013.png'),pygame.image.load('Animations/Enemy/Default/014.png'),pygame.image.load('Animations/Enemy/Default/015.png')]
    walkleft=[pygame.image.load('L1E.png'),pygame.image.load('L2E.png'),pygame.image.load('L3E.png'),pygame.image.load('L4E.png'),pygame.image.load('L5E.png'),pygame.image.load('L6E.png'),pygame.image.load('L7E.png'),pygame.image.load('L8E.png'),pygame.image.load('L9E.png'),pygame.image.load('L10E.png'),pygame.image.load('L11E.png')]
    bug=[pygame.image.load('Animations/BugEnemy/Default/001.png'),pygame.image.load('Animations/BugEnemy/Default/002.png'),pygame.image.load('Animations/BugEnemy/Default/003.png'),pygame.image.load('Animations/BugEnemy/Default/004.png'),pygame.image.load('Animations/BugEnemy/Default/005.png'),pygame.image.load('Animations/BugEnemy/Default/006.png'),pygame.image.load('Animations/BugEnemy/Default/007.png'),pygame.image.load('Animations/BugEnemy/Default/008.png'),pygame.image.load('Animations/BugEnemy/Default/009.png'),pygame.image.load('Animations/BugEnemy/Default/010.png'),pygame.image.load('Animations/BugEnemy/Default/011.png'),pygame.image.load('Animations/BugEnemy/Default/012.png'),pygame.image.load('Animations/BugEnemy/Default/013.png'),pygame.image.load('Animations/BugEnemy/Default/014.png'),pygame.image.load('Animations/BugEnemy/Default/015.png')]
    expl=[pygame.image.load('Animations/Explosion2/Default/000.png'),pygame.image.load('Animations/Explosion2/Default/001.png'),pygame.image.load('Animations/Explosion2/Default/002.png'),pygame.image.load('Animations/Explosion2/Default/003.png'),pygame.image.load('Animations/Explosion2/Default/004.png'),pygame.image.load('Animations/Explosion2/Default/005.png'),pygame.image.load('Animations/Explosion2/Default/006.png'),pygame.image.load('Animations/Explosion2/Default/007.png')]
    expm=[pygame.image.load('Animations/Explosion3/Default/000.png'),pygame.image.load('Animations/Explosion3/Default/001.png'),pygame.image.load('Animations/Explosion3/Default/002.png'),pygame.image.load('Animations/Explosion3/Default/003.png'),pygame.image.load('Animations/Explosion3/Default/004.png'),pygame.image.load('Animations/Explosion3/Default/005.png'),pygame.image.load('Animations/Explosion3/Default/006.png'),pygame.image.load('Animations/Explosion3/Default/007.png'),pygame.image.load('Animations/Explosion3/Default/008.png'),pygame.image.load('Animations/Explosion3/Default/009.png'),pygame.image.load('Animations/Explosion3/Default/010.png'),pygame.image.load('Animations/Explosion3/Default/011.png'),pygame.image.load('Animations/Explosion3/Default/012.png'),pygame.image.load('Animations/Explosion3/Default/013.png'),pygame.image.load('Animations/Explosion3/Default/014.png'),pygame.image.load('Animations/Explosion3/Default/015.png'),pygame.image.load('Animations/Explosion3/Default/016.png'),pygame.image.load('Animations/Explosion3/Default/017.png'),pygame.image.load('Animations/Explosion3/Default/018.png'),pygame.image.load('Animations/Explosion3/Default/019.png'),pygame.image.load('Animations/Explosion3/Default/020.png'),pygame.image.load('Animations/Explosion3/Default/021.png'),pygame.image.load('Animations/Explosion3/Default/022.png'),pygame.image.load('Animations/Explosion3/Default/023.png'),pygame.image.load('Animations/Explosion3/Default/024.png'),pygame.image.load('Animations/Explosion3/Default/025.png'),pygame.image.load('Animations/Explosion3/Default/026.png'),pygame.image.load('Animations/Explosion3/Default/027.png'),pygame.image.load('Animations/Explosion3/Default/028.png'),pygame.image.load('Animations/Explosion3/Default/029.png'),pygame.image.load('Animations/Explosion3/Default/030.png'),pygame.image.load('Animations/Explosion3/Default/031.png'),pygame.image.load('Animations/Explosion3/Default/032.png'),pygame.image.load('Animations/Explosion3/Default/033.png'),pygame.image.load('Animations/Explosion3/Default/034.png'),pygame.image.load('Animations/Explosion3/Default/035.png'),pygame.image.load('Animations/Explosion3/Default/036.png'),pygame.image.load('Animations/Explosion3/Default/037.png'),pygame.image.load('Animations/Explosion3/Default/038.png'),pygame.image.load('Animations/Explosion3/Default/039.png')]
    def __init__(self,x,y,width,height,end):
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.end=end
        self.walk=0
        self.vel=3
        self.path=[self.x,self.y]
        self.box=(self.x+20,self.y,28,60)
        self.health=1000
        self.visible=True
        self.exp=False
        self.e=0
        self.ec=0
       
    def draw(self,win):
        self.move()
        if self.e>=21:
            self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=-50
            self.draw2(win)
            self.ec=0
            self.e=0
            
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=15:
                self.walk=0
            if self.vel>0:
                win.blit(self.walkright[self.walk],(self.x,self.y))
                self.walk+=1
            else:
                win.blit(self.walkright[self.walk],(self.x,self.y))
                self.walk+=1
            #pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            #pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
            #pygame.draw.rect(win,(255,0,0),self.box,2)
    def draw2(self,win):
        self.move()
        if self.e>=21:
            self.e=0
        if self.ec>21 and self.exp==True:
            self.exp=False
            self.visible=True
            self.x=randint(0,500)
            self.y=randint(-100,0)
            
            self.draw2(win)
            self.ec=0
            self.e=0
            
        if self.exp:
            win.blit(self.expl[self.e//3],(self.x,self.y))
            self.ec+=1
            self.e+=1
        if self.visible:
            if self.walk+1>=15:
                self.walk=0
            if self.vel>0:
                win.blit(self.bug[self.walk],(self.x,self.y))
                self.walk+=1
            else:
                win.blit(self.bug[self.walk],(self.x,self.y))
                self.walk+=1
            #pygame.draw.rect(win,(255,0,0),(self.box[0],self.box[1]-20,50,10))
            #pygame.draw.rect(win,(0,0,0),(self.box[0],self.box[1]-20,(50-(5*(100-self.health)))/100,10))
            self.box=(self.x+5,self.y-5,60,80)
            #pygame.draw.rect(win,(255,0,0),self.box,2)
        
    
    def move(self):
        if self.y<700:
            self.y+=1.5
        else:
            self.x=randint(0,600)
            self.y=-50
        if self.x>0:
            self.x+=self.vel
        if self.x>=600:
            self.vel*=-1
        elif self.x<=0:
            self.x=10
            self.vel*=-1
            
    def hit(self):
        if self.health>0:
            self.health-=100
        else:
            deadso.play()
            self.visible=False
            self.exp=True
            self.health=1000
    
    pygame.display.update()
            

def redrawgamewimdow():
    win.blit(bg,(0,0))
    text=font.render('SCORE:'+str(score),1,(0,255,0))
    win.blit(text,(390,40))
    text=font.render('AMMO:'+str(ammo),1,(0,255,0))
    
    win.blit(text,(0,80))
    text=font.render('HEALTH:'+str(health),1,(0,255,0))
    win.blit(text,(0,40))
    man.draw(win)
    e.draw(win)
    e2.draw2(win)
    e3.draw(win)
    e4.draw2(win)
    
    
    
    for bullet in bullets:
        bullet.draw(win)
    pygame.display.update()
    
                
pygame.mixer.music.play(-1)
font=pygame.font.SysFont('comicsans',30,True)
man = actor(250, 600, 64, 64)
e=enemy(100,40,64,64,450)
bullets=[]
e2=enemy(200,100,64,64,100)
e3=enemy(200,0,64,64,100)
e4=enemy(0,0,64,64,100)

run=True
shoot=0
ammo=1000
i=0     

    
while run:
    if health<0 or ammo<0:
        i=5
        health=400
        e.x=100
        e.y=40
        e2.x=200
        e2.y=-50
        e3.x=200
        e3.y=0
        e4.x=0
        e4.y=0
        man.x=250
        man.y=600
        
        
    if (e.visible==True or e2.visible==True or e3.visible==True or e4.visible==True) and i!=5:
        if man.box[1]<e.box[1]+e.box[3] and man.box[1]+man.box[3] >e.box[1]:
            if man.box[0]+man.box[2]>e.box[0] and man.box[0]<e.box[0]+e.box[2]:
                man.hit()
                e.hit()
                col.play()
                health-=10
                score-=50
                ammo-=20
        if man.box[1]<e2.box[1]+e2.box[3] and man.box[1]+man.box[3] >e2.box[1]:
            if man.box[0]+man.box[2]>e2.box[0] and man.box[0]<e2.box[0]+e2.box[2]:
                man.hit()
                health-=10
                col.play()
                e2.hit()
                score-=50
                ammo-=20
        if man.box[1]<e3.box[1]+e3.box[3] and man.box[1]+man.box[3] >e3.box[1]:
            if man.box[0]+man.box[2]>e3.box[0] and man.box[0]<e3.box[0]+e3.box[2]:
                man.hit()
                health-=10
                col.play()
                e3.hit()
                score-=50
                ammo-=20
        if man.box[1]<e4.box[1]+e4.box[3] and man.box[1]+man.box[3] >e4.box[1]:
            if man.box[0]+man.box[2]>e4.box[0] and man.box[0]<e4.box[0]+e4.box[2]:
                man.hit()
                health-=10
                col.play()
                score-=50
                e4.hit()
                ammo-=20
        
    
    if shoot>0:
       shoot+=0
    if shoot>3:
        shoot=0
    clock.tick(27)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    for bullet in bullets:
        if bullet.y<e.box[1]+e.box[3] and bullet.y>e.box[1] and e.y>0:
            if bullet.x>e.box[0] and bullet.x<e.box[0]+e.box[2]:
                e.hit()
                
                score+=100
                ammo+=2
                bullet.y=-550
                bullet.x=-550
            
        if bullet.y<e2.box[1]+e2.box[3] and bullet.y>e2.box[1] and e2.y>0:
            if bullet.x>e2.box[0] and bullet.x<e2.box[0]+e2.box[2]:
                e2.hit()
                
                score+=100
                ammo+=2
                bullet.y=-550
                bullet.x=-550
        if bullet.y<e3.box[1]+e3.box[3] and bullet.y>e3.box[1] and e3.y>0:
            if bullet.x>e3.box[0] and bullet.x<e3.box[0]+e3.box[2]:
                e3.hit()
                
                score+=100
                ammo+=2
                bullet.y=-550
                bullet.x=-550
        if bullet.y<e4.box[1]+e4.box[3] and bullet.y>e4.box[1] and e4.y>0:
            if bullet.x>e4.box[0] and bullet.x<e4.box[0]+e4.box[2]:
                e4.hit()
                
                score+=100
                ammo+=2
                bullet.y=-550
                bullet.x=-550
            
        if bullet.y<1000 and bullet.y>-100:
            bullet.y-=bullet.vel
        else:
            bullet.x=-550
            bullet.y=-550
    
    
    ke=pygame.key.get_pressed()
    if ke[pygame.K_SPACE]:
        bulletso.play()
        ammo-=1
        man.fire=True
        if i==0 or i==5:
            health=400
            score=0
            ammo=1000
            bg=pygame.image.load('backg.gif')
            i=10
        if man.left:
            facing=1
        else:
            facing=1
          
        if len(bullets)>-5:
            bullets.append(project(round (man.x+man.width//2),round(man.y+man.height//2),6,(0,0,0),facing))
    else:
        man.fire=False
                                         
    if ke[pygame.K_LEFT] and man.x>0:
        man.x-=man.vel
        man.left=True
        man.right=False
        man.standing=False
    elif ke[pygame.K_RIGHT] and man.x<600:
        man.x+=man.vel
        man.right=True
        man.left=False
        man.standing=False
    else:
        man.standing=True
        man.right=False
        man.left=False
        man.walk=0
    
    if ke[pygame.K_UP]:
        man.thrust=True
        man.y-=man.vel
    else:
        man.thrust=False
    if ke[pygame.K_DOWN]:
       
        man.y+=man.vel
        

    if i==10:
        redrawgamewimdow()
    elif i==5:
        sc=score
        text=font.render('YOUR SCORE WAS:'+str(sc),6,(0,255,0))
        win.blit(text,(290,80))
        
        bg=pygame.image.load('002.png')
        win.blit(bg,(0,200))

        
    if i==0:
        win.blit(bg,(0,200))
    pygame.display.update()
    
pygame.quit()
