import pygame as p
win=p.display.set_mode((700,480))
p.draw.rect(win,(255,0,0),50,50,50,50,2)
pygame.display.update()
